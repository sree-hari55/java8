package demo;
import java.util.Arrays;
import java.util.List;

public class ProfileServiceImpl {

	public static List<ProfileInfo> getProfileInfos(){
		return Arrays.asList(new ProfileInfo("danniel", "michel", "qwertyuioasdfg2345","liteuser"),
				new ProfileInfo("sachin", "tendulkar", "qwertyuioasdfg23451234wertd","liteuser"),
				new ProfileInfo("rohit", "sharma", "qwertyu1234567fghj","liteuser"),
				new ProfileInfo("smith", "steve", "qwertyuioasdfg234523456","fullyregistration"),
				new ProfileInfo("david", "warner", "q123456gytdcytf","fullyregistration"),
				new ProfileInfo("jos", "butterler", "qwertyuioasdfg2345tyu","liteuser"),
				new ProfileInfo("ben", "stokes", "qwertyuioasdfg2345ghjjd","fullyregistration"),
				new ProfileInfo("azim", "amla", "qwertyuioasdfg23456rfgt","liteuser"));
		
	}
}
