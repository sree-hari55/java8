package demo;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class GroupByInterviewQuestionsTest {

	public static void main(String[] args) {
		String str="sreehari";
		String[] chars=str.split("");
		System.out.println(Arrays.toString(chars));
		Map<Object, List<String>> map=Arrays.stream(chars).collect(Collectors.groupingBy(s->s));

		System.out.println(map);

		// count of each character in given string
		Map<Object, Long> countOfEachcharacter=Arrays
				.stream(chars)
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println("count of each character in given string:"+countOfEachcharacter);

		// Duplicates characters in given string

		List<String> duplicatesCharacters=Arrays
				.stream(chars)
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
				.entrySet()
				.stream()
				.filter(s -> s.getValue()>1)
				.map(s -> s.getKey())
				.collect(Collectors.toList());
		System.out.println("Duplicates characters in given string:"+duplicatesCharacters);

		// Unique characters in given string

		List<String> uniqueCharacters=Arrays
				.stream(chars)
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
				.entrySet()
				.stream()
				.filter(s -> s.getValue()==1)
				.map(s -> s.getKey())
				.collect(Collectors.toList());
		System.out.println("Unique characters in given string:"+uniqueCharacters);

		// first non repeated element in given string	
		/** Here the default map implementation is hashmap in hashmap the insertion order is not preserved.**/

		String firstNonRepeatedElement=Arrays
				.stream(chars)
				.collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
				.entrySet()
				.stream()
				.filter(s -> s.getValue()==1)
				.findFirst().get().getKey();

		System.out.println("first non Repeated Element in given string:"+firstNonRepeatedElement);


		//2nd height no in given array

		int[] arr= {10,20,30,40,50,7,8,90};
		Integer heightNo=Arrays
				.stream(arr)
				.boxed()
				.sorted(Comparator.reverseOrder())
				.skip(1)
				.findFirst().get();

		System.out.println("2nd height no:"+heightNo);



		//2nd lowest no in given array

		int[] arr1= {10,20,30,40,50,7,8,90};
		Integer lowestNo=Arrays
				.stream(arr1)
				.boxed()
				.sorted()
				.skip(1)
				.findFirst().get();

		System.out.println("2nd lowest no:"+lowestNo);


		/** find longest string in given array**/
		// reduce method is best for comparison

		String[] stringArray= {"firstName","userName","middleName","lastname"};

		String logestString=Arrays
				.stream(stringArray)
				.reduce((word1,word2) -> word1.length()>word2.length()?word1:word2).get();
		System.out.println("longest string in given array:"+logestString);

		// find all elements from array who's starts with 1 [1,5,56,7,12,21,19] => [1,12,19]

		int[] numbers= {1,5,56,7,12,21,19};
		List<String> startWithList=Arrays.stream(numbers)
				.boxed()
				.sorted()
				.map(s -> s+"")
				.filter(s -> s.startsWith("1"))
				.collect(Collectors.toList());

		System.out.println("find all elements from array who's starts with 1:"+startWithList);

		// String.join method example

		List<String> nos=Arrays.asList("1","2","3","4","5");

		String results=String.join("-", nos);

		System.out.println("join method results:"+results);


		// skip and limit method use case example
		// best use case while reading csv files the first line is headers we can skip those line using skip() and we can control how many lines we can read in the files using limit() 

		IntStream.rangeClosed(1, 10)
		.skip(1)
		.limit(8)
		.forEach(System.out::println);

		
		// sort a list and map
		
		// map() and flatMap()

	}
}