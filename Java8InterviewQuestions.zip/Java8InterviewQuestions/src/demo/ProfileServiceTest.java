package demo;
import java.util.List;
import java.util.stream.Collectors;

public class ProfileServiceTest {

	public static void main(String[] args) {
		List<List<ProfileInfo>> profileMap=ProfileServiceImpl
				.getProfileInfos()
				.stream()
				.collect(Collectors.groupingBy(ProfileInfo::getProfileType))
				.entrySet()
				.stream()
				.filter(p -> p.getKey().equals("liteuser"))
				.map(p ->p.getValue())
				.collect(Collectors.toList());
		System.out.println(profileMap);

	}

}
