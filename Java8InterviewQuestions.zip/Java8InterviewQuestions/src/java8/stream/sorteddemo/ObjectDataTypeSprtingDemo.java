package java8.stream.sorteddemo;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import demo.ProfileInfo;
import demo.ProfileServiceImpl;

public class ObjectDataTypeSprtingDemo {
	public static void main(String[] args) {
		List<ProfileInfo> profileInfos=ProfileServiceImpl.getProfileInfos();
		Collections.sort(profileInfos, new MyFirstNameSortedComparator());
		
		//Simplifying approach  
		
		Collections.sort(profileInfos, new Comparator<ProfileInfo>() {

			@Override
			public int compare(ProfileInfo o1, ProfileInfo o2) {
				return o1.getFirstName().compareTo(o2.getFirstName());
			}
			
		});
		System.out.println(profileInfos);
		
	}

}

class MyFirstNameSortedComparator implements Comparator<ProfileInfo>{

	@Override
	public int compare(ProfileInfo o1, ProfileInfo o2) {
		return o1.getFirstName().compareTo(o2.getFirstName());
	}
	
}

