package java8.stream.sorteddemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PremitivesDataTypeSortedApproach1Demo {

	public static void main(String[] args) {
		List<Integer> list=new ArrayList<>();
		list.add(5);
		list.add(10);
		list.add(7);
		list.add(3);
		
		Collections.sort(list); // ascending order
		Collections.reverse(list); //descending order
		System.out.println(list);
		
		list=list.stream().sorted().collect(Collectors.toList()); // ascending order
		list=list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(list);
		
	}

}
