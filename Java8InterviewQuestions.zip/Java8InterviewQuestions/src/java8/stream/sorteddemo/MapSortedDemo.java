package java8.stream.sorteddemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import demo.ProfileInfo;

public class MapSortedDemo {

	public static void main(String[] args) {
		/** Primitives **/
		Map<String,Integer> map=new HashMap<>();
		map.put("one",1);
		map.put("four",4);
		map.put("eight",8);
		map.put("five",5);

		// Traditional approach
		List<Entry<String, Integer>> list=new ArrayList<>(map.entrySet());


		Collections.sort(list,new Comparator<Entry<String, Integer>>() {

			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return o1.getKey().compareTo(o2.getKey());
			}

		});

		// lambda approach 

		Collections.sort(list,(o1,o2) ->o1.getKey().compareTo(o2.getKey()));
		System.out.println(list);

		// sorting on primitives

		map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);


		/** Playing with Object **/

		Map<ProfileInfo,Integer> pMap=new HashMap<>();
		pMap.put(new ProfileInfo("danniel", "michel", "qwertyuioasdfg2345","liteuser"),1);
		pMap.put(new ProfileInfo("sachin", "tendulkar", "qwertyuioasdfg23451234wertd","liteuser"),4);
		pMap.put(new ProfileInfo("smith", "steve", "qwertyuioasdfg234523456","fullyregistration"),8);
		pMap.put(new ProfileInfo("ben", "stokes", "qwertyuioasdfg2345ghjjd","fullyregistration"),5);

		// Traditional approach
		List<Entry<ProfileInfo,Integer>> entryList=new ArrayList<>(pMap.entrySet());


		Collections.sort(entryList,new Comparator<Entry<ProfileInfo,Integer>>() {

			@Override
			public int compare(Entry<ProfileInfo, Integer> o1, Entry<ProfileInfo, Integer> o2) {
				return o1.getKey().getFirstName().compareTo(o2.getKey().getFirstName());
			}
		});
		
		System.out.println(entryList);
		
		//2nd approach 
		
		Map<ProfileInfo,Integer> treeMap=new TreeMap<>((o1,o2) -> o2.getFirstName().compareTo(o1.getFirstName()));
		treeMap.put(new ProfileInfo("danniel", "michel", "qwertyuioasdfg2345","liteuser"),1);
		treeMap.put(new ProfileInfo("sachin", "tendulkar", "qwertyuioasdfg23451234wertd","liteuser"),4);
		treeMap.put(new ProfileInfo("smith", "steve", "qwertyuioasdfg234523456","fullyregistration"),8);
		treeMap.put(new ProfileInfo("ben", "stokes", "qwertyuioasdfg2345ghjjd","fullyregistration"),5);
		
		System.out.println(treeMap);

		// sorting on objects
		
		pMap.entrySet().stream().sorted(Map.Entry.comparingByKey((o1,o2) -> o2.getFirstName().compareTo(o1.getFirstName()))).forEach(System.out::println);
		pMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);

	}

}
