package java8.stream.sorteddemo;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import demo.ProfileInfo;
import demo.ProfileServiceImpl;

public class ObjectDatatypeSortingUsingJava8 {
	public static void main(String[] args) {
		List<ProfileInfo> profileInfos=ProfileServiceImpl.getProfileInfos();

		// approach-1
		List<String> firstNames=profileInfos.stream().sorted((o1,o2) -> o1.getFirstName().compareTo(o2.getFirstName())).map(ProfileInfo::getFirstName).collect(Collectors.toList());


		// approach-2
		firstNames=profileInfos.stream().sorted(Comparator.comparing(p ->p.getFirstName())).map(ProfileInfo::getFirstName).collect(Collectors.toList());

		// approach-3
		firstNames=profileInfos.stream().sorted(Comparator.comparing(ProfileInfo::getFirstName)).map(ProfileInfo::getFirstName).collect(Collectors.toList());
		System.out.println(firstNames);
	}
}
