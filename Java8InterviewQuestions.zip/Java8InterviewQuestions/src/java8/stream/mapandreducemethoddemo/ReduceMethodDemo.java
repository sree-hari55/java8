package java8.stream.mapandreducemethoddemo;

import java.util.Arrays;
import java.util.List;

import demo.ProfileInfo;
import demo.ProfileServiceImpl;

public class ReduceMethodDemo {
	
	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(2,3,4,6,8,4);
		
		//approach-1 
		list.stream().mapToInt(i ->i).sum();
		
		//approach-2
		
		int sum=list.stream().reduce((a,b) ->a+b).get();
		
		 sum=list.stream().reduce(0,(a,b) ->a+b);
		 
		 sum=list.stream().reduce(Integer::sum).get();
		
		System.out.println(sum);
		
		// Objects 
		List<ProfileInfo> profileInfos=ProfileServiceImpl.getProfileInfos();
	String firstNames=profileInfos
		.stream()
		.map(ProfileInfo::getFirstName)
		.reduce((word1,word2) -> word1.length()>word2.length()?word1:word2).get();
		System.out.println(firstNames);
	}

}
