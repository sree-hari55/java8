package java8.methodReference;

import demo.ProfileInfo;

public class ConstructorMethodReference {

	public static void main(String[] args) {

		// syntax : reference::new

		MyFunctionalInterface1 mf = ProfileInfo::new;

		System.out.println(mf.getProfileInfo());//Student class toString() call

	}
}

@FunctionalInterface
interface MyFunctionalInterface1 {

	ProfileInfo getProfileInfo();
}