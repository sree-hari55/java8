package java8.methodReference;

import demo.ProfileServiceImpl;

public class StaticMethodReferenceExample {
	public static void main(String[] args) {

		// out is printstream class references 
		ProfileServiceImpl.getProfileInfos().forEach(System.out::println);
	}
}
