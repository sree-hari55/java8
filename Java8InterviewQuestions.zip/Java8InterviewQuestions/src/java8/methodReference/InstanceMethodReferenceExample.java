package java8.methodReference;

import java.util.List;
import java.util.stream.Collectors;

import demo.ProfileInfo;
import demo.ProfileServiceImpl;

public class InstanceMethodReferenceExample {
	
	public static void main(String[] args) {

		// instance Method Reference
		
		
		ProfileService service=new ProfileService();
		List<ProfileInfoDto> profileList=ProfileServiceImpl.getProfileInfos().stream().map(service::convert).collect(Collectors.toList());
		
		System.out.println(profileList);
		
		/**
		 * note : if method doesn't have any arguments/parameters then the java stream API 
		 * will think like it's static method we can call by using something like ClassName::methodName 
		 * 
		 * If method having arguments then the java stream API will think like instance method, we 
		 * need to call using reference::methodName
		 * 
		 * **/
		
		List<String> StringNames=ProfileServiceImpl.getProfileInfos().stream().map(ProfileInfo::getFirstName).collect(Collectors.toList());
		System.out.println(StringNames);
	}
}


class ProfileInfoDto{
	String firstName;
	String lastName;
	String userName;
	String profileType;

	public ProfileInfoDto(String firstName, String lastName, String userName, String profileType) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.profileType = profileType;
	}
	public ProfileInfoDto() {
		super();
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getProfileType() {
		return profileType;
	}
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	@Override
	public String toString() {
		return "ProfileInfoDto [firstName=" + firstName + ", lastName=" + lastName + ", userName=" + userName
				+ ", profileType=" + profileType + "]";

	}	
}
class ProfileService{

	ProfileInfoDto convert(ProfileInfo profileInfo){
		return new ProfileInfoDto(profileInfo.getFirstName(),profileInfo.getLastName(),profileInfo.getUserName(),profileInfo.getProfileType());
	}
}
