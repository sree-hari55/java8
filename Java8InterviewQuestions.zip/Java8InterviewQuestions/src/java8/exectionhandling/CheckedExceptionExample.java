package java8.exectionhandling;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class CheckedExceptionExample {
	public static void main(String[] args) {

		//handle exception for checkedException
        List<Integer> list2 = Arrays.asList(10,20);

        list2.forEach(i->{
            try {
				Thread.sleep(i);
				 System.out.println(i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
           });
        
        // approach-2 
        list2.forEach(handleCheckedExceptionConsumer(i->{
            Thread.sleep(i);
            System.out.println(i);
        }));
        
        
	}
	
	 static  <Target> Consumer<Target> handleCheckedExceptionConsumer(CheckedExceptionHandlerConsumer<Target,Exception> handlerConsumer){
	        return obj -> {
	            try {
	                handlerConsumer.accept(obj);
	            } catch (Exception ex) {
	                throw new RuntimeException(ex);
	            }
	        };
	    }
}

@FunctionalInterface
interface CheckedExceptionHandlerConsumer<Target,ExObj extends Exception> {

    public void accept(Target target) throws ExObj;
}