package java8.exectionhandling;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class UncheckedExceptionHandlingExample {

	public static void main(String[] args) {
		List<String> list=Arrays.asList("234","ftfy","4789");

		//list.forEach(n -> System.out.println(Integer.parseInt(n)));

		//approach -1

		list.forEach(n ->{
			try {
				System.out.println(Integer.parseInt(n));
			} catch (NumberFormatException e) {
				System.out.println("Exception "+e.getMessage());
			}
		});

		// 2nd approach 

		list.forEach(n -> handle(n));

		// 3rd approach

		list.forEach(handleException(s -> System.out.println(Integer.parseInt(s))));

		// final, best and generic approach
		
		list.forEach(handleGenericException(s -> System.out.println(Integer.parseInt(s)),NumberFormatException.class));

	}

	public static void handle(String n) {
		try {
			System.out.println(Integer.parseInt(n));
		} catch (NumberFormatException e) {
			System.out.println("Exception "+e.getMessage());
		}
	}

	static Consumer<String> handleException(Consumer<String> str){
		return obj -> {
			try {
				str.accept(obj);
			} catch (Exception ex) {
				System.out.println("exception : " + ex.getMessage());
			}
		};
	}

	static <Target,ExObj extends Exception> Consumer<Target> handleGenericException(Consumer<Target> consumer,Class<ExObj> exe){
		return obj -> {
			try {
				consumer.accept(obj);
			} catch (Exception ex) {
				try {
                    ExObj exObj = exe.cast(ex);
                    System.out.println("exception : " + exObj.getMessage());
                } catch (ClassCastException ecx) {
                    throw ex;
                }
			}
		};
	}
}
