package java8.skipandlimitdemo;

import java.util.Arrays;
import java.util.List;

public class SkipAndLimitExample {
	public static void main(String[] args) {

		// Skip Operation is useful when we want to discard some elements from actual collection.
		// limit operation is useful when we want to read till particular position.
		
		List<Integer> list=Arrays.asList(1,3,4,5,6,7,8,8,9,10);
		
		list.stream().skip(2).limit(5).forEach(System.out::println);
		
		// real time example 
		
		/**
		 * In real time while reading the csv files we need to skip the header and footer 
		 * 
		 * in that time skip and limit method is the best.
		 * 
		 * **/
		
	}
}
