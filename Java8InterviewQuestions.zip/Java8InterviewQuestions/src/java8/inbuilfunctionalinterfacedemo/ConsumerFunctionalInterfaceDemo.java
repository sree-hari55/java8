package java8.inbuilfunctionalinterfacedemo;

import java.util.function.Consumer;

import demo.ProfileServiceImpl;

public class ConsumerFunctionalInterfaceDemo {

	public static void main(String[] args) {
		Consumer<String> consumer=(s) -> System.out.print(s);
		
		consumer.accept("consumer");
		ProfileServiceImpl.getProfileInfos().forEach(System.out::println);
	}
}
