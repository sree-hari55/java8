package java8.inbuilfunctionalinterfacedemo;

import java.util.function.Predicate;

import demo.ProfileServiceImpl;

public class PredicateFunctionalInterfaceDemo {
	
	public static void main(String[] args) {
		
		Predicate<String> predicate=(s)->{
			if(s.equals("sreehari")) {
				return true;
			}else {
				return false;
			}
		};
		System.out.println(predicate.test("sreehari"));
		ProfileServiceImpl.getProfileInfos().stream().filter(s -> "rohit".equals(s.getFirstName())).forEach(System.out::println);
	
		
	}

}
