package java8.inbuilfunctionalinterfacedemo;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import demo.ProfileServiceImpl;

public class FunctionFunctionalInterfaceDemo {

	public static void main(String[] args) {
	Function<String,String> function=(s) -> s+"restdyuio";
	
	System.out.println(function.apply("okay"));
	
	List<String> profileInfos=ProfileServiceImpl.getProfileInfos().stream().map(p -> p.getFirstName()+p.getLastName()).collect(Collectors.toList());;
	System.out.println(profileInfos);
	}

}
