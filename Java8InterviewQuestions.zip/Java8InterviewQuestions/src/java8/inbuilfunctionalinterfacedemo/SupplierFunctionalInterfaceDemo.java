package java8.inbuilfunctionalinterfacedemo;

import java.util.function.Supplier;

import demo.ProfileInfo;
import demo.ProfileServiceImpl;

public class SupplierFunctionalInterfaceDemo {

	public static void main(String[] args) {
		Supplier<String> supplier=()-> "okay";
		System.out.println(supplier.get());
		
		ProfileInfo p=ProfileServiceImpl.getProfileInfos().stream().findAny().orElse(new ProfileInfo());
		System.out.println(p);
	}

}
