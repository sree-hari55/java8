package java8;


public class LambdaExpressionTest {

	// lambda expression

	/**
	 * 
	 * The Expression through which we can represent an anonymous function
	 * 
	 * Anonymous: Nameless/Unknown
	 * 
	 * Anonymous function : A method who don't have any name or modifier
	 * 
	 * syntax: () -> System.out.println("lambda syntax");
	 * 
	 *  note: we can't write lambda expression for all the methods, it is applicable only for abstract methods 
	 * inside the functional interface. 
	 * 
	 **/

	// functional interface

	/**
	 * 
	 * An Interface who contains only one abstract method but can have multiple default and static method 
	 * is called functional interface.
	 * 
	 * Ex: Runnable -> run()
	 * Callable -> call()
	 * comparable -> compareTo()
	 * comparator -> compare()
	 * 
	 * We can find the @funtionalInterface annotation in the class level
	 * 
	 **/

	// Example 
	public static void main(String[] args) {
		Cal c=()-> System.out.println("lambda expression");
		c.switchOn();
	}
}
interface Cal{
	void switchOn();
}